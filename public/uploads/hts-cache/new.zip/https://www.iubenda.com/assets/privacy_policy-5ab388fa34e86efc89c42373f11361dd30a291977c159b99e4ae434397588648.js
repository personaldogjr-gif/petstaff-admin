<!DOCTYPE html>
<html id="home">
  <head>
    <title>Page Not Found</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta property="og:title" content="iubenda - generatore di Privacy Policy" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://www.iubenda.com/images/site/fb-image.png" />
    <meta property="og:site_name" content="iubenda" />
    <meta property="fb:admins" content="190131204371223" />
    <link rel="image_src" href="https://www.iubenda.com/images/site/fb-image.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/assets/maintenance.css" media="screen" rel="stylesheet" type="text/css" />
    <script src="/assets/maintenance.js" type="text/javascript"></script>
  </head>
  <body style="height: 100%;" id="v1">
    <div class="container">
      <div class="header">
        <div class="inner_centered pt-4">
          <div class="logo">
            <a href="https://www.iubenda.com" title="iubenda"><img alt="iubenda" width="90" src="/assets/site/general/logo.svg" /></a>
          </div>
          </div><!-- /inner_centered -->
          </div><!-- /header -->
          
          <div class="error_page cf text-center py-4 mb-4">
            <img src="/assets/site/artworks/404_img.png" />
            <h1>Page Not Found</h1>
            <p>
              Double-check the address in the navigation bar <br />or <a href="#" onclick="location.reload(); return false;">Reload</a> this page (it may be a momentary issue).
            </p>
            <p>
              If you really believe that the page should work,<br /><a class="link-underline" href="mailto:info@iubenda.com">drop us a line</a> or <a class="link-underline" href="http://twitter.com/iubenda\" target="_blank">send a tweet</a> :)
            </p>
            <p class="flex-column d-flex col-lg-4 col-md-6 mx-auto">
              <br />
              <a href="/" class="btn btn-secondary text-white mb-2">Go back to the home page</a> or <a href="#" class="btn btn-secondary text-white mt-2" onclick="location.reload(); return false;">Reload</a>
            </p>
            </div><!-- /inner_centered -->
            </div><!-- /container-->
            
            <footer class="bg-light-gray text-sm pt-4">
              
              <div class="text-center">
                <ul class="d-md-flex justify-content-center list-unstyled mb-0 text-xs">
                  <li class="list-inline-item d-block d-md-inline-block mr-md-3">                  <a href="https://www.iubenda.com/privacy-policy/252372" class="iubenda-white iubenda-embed" title="Privacy Policy">Privacy Policy</a>
                  <script type="text/javascript">(function (w,d) {var loader = function () {var s = d.createElement("script"), tag = d.getElementsByTagName("script")[0];
                  s.src = "https://cdn.iubenda.com/iubenda.js";tag.parentNode.insertBefore(s,tag);};
                w.addEventListener ? w.addEventListener("load", loader, false) : w.attachEvent("onload", loader);})(window, document);</script></li>
                <li class="list-inline-item d-block d-md-inline-block mr-md-3"><a href="//www.iubenda.com/en/user/tos" class="iubenda-white iubenda-embed" title="Terms of service">Terms and Conditions</a></li>
                <li class="list-inline-item d-block d-md-inline-block mr-md-3"><a href="/en/help/158">Imprint/Impressum</a></li>
                <li class="list-inline-item d-block d-md-inline-block mb-md-2 mr-md-3"><a href="https://www.iubenda.com/privacy-policy/94654098">Consent Solution Privacy Notice</a></li>
                <li class="list-inline-item d-block d-md-inline-block mr-md-3"><a href="https://www.iubenda.com/privacy-policy/36700132">Cookie Solution Privacy Notice</a></li>
              </ul>
            </div>
            <hr class="p-0">
            <div class="p-4 text-xs">
              <div class="container">
                <div class="row">
                  <div class="col-md-3">
                    <address>
                      <strong>iubenda s.r.l</strong><br>Via San Raffaele, 1 - 20121 Milan (Italia)<br>C.F./P.IVA: IT07347120961<br>Camera di Commercio di Milano<br>CS: 12987 Eur (I.V.)
                    </address>
                  </div>
                  <div class="col-md-9">
                    Content available on iubenda.com and documents generated using the Service are intended for general information purposes only. Although all clauses and provisions inside the generator database have been drafted by a team of highly qualified legal experts and regularly undergo reviews and updates, documents are generated in a fully automated manner and therefore do not constitute or substitute the rendering of legal advice, nor does any assistance and customer support provided by iubenda establish an attorney-client relationship. This is why, despite all efforts in offering the best possible service, iubenda cannot guarantee generated documents to be fully compliant with applicable law. Users should therefore not rely upon documents generated using iubenda without seeking legal advice from an attorney licensed in the relevant jurisdiction(s).
                  </div>
                </div>
              </div>
              
            </footer>
            
          </body>
        </html>